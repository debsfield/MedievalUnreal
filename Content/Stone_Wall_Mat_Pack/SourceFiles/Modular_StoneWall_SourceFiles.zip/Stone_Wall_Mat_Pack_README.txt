Substance Materials Documentation

Requires the substance plugin be installed. When that's done, open UE4, go to Edit > Plugins and enable the Substance plugin. 

Next make sure that the GPU Engine is enabled. This can be done by going to Edit -> Project Settings -> Scroll down to the bottom to Plugins/Substance -> Under 'Cooking', change the Substance Engine dropdown to GPU Engine.

Now restart UE4 and then you should be good to go.

===========================================================================
===========================================================================

-------------------------------------------------------------------
SUBSTANCE MATERIAL CONTROLS DOCUMENTATION.
-------------------------------------------------------------------

Substance material Controls can be found in the Textures Folder. They are the red colored files and each one effects the corresponding textures of the same name.

It is reccomended to drop the substance material down to a lower resolution for faster responce time to changes made with the controls. When you are satisfied bring the resolution back up to your desired output.


=================================================================================
MODULAR STONEWALL
=================================================================================


Normal Intensity: Controls the strength of the normal map.

---------------------------------------------------------------------------------
Color
---------------------------------------------------------------------------------
3 color pickers for the stones

1 color picker for the plaster

1 color picker for Dirt

Stone Highlight Lightness: Controls the intensity of the stone highlights in the diffuse.

Stone Highlight Range: Controls the spread of the stone highlight.

Stone Highlight Contrast: Secondary control that works with Stone Highlight Range.

Stone Secondary Highlight Opacity: Controls the strength of a secondary highlight.

-----------------------------------------------------------------------------------
Pattern
-----------------------------------------------------------------------------------
Pattern Switch: switches between 4 different patterns.

-----------------------------------------------------------------------------------
Straight Pattern
-----------------------------------------------------------------------------------

Stone Shape Switch: Changes the base stone shape used in the pattern.

Number X: Number of stones in a row.

Number Y: Number of rows in the pattern.

Straight Pattern Rotation Random: Rotates each stone in a random direction.

Edge Soften: Makes the stone less sharp.

Middle Size: Shape variation control for the stone shapes in each row.

Stone Scale: Controls the overall size of the stones.

Shape Breakup: adds imperfections to the stone shapes.

Slope Variation: Adds more veriety to the stone shapes.

Height Varieation: Varies the height of each stone in the pattern.

Stone Scale Variation: Varies the size of each of the stones.

Interstice: More shape controls for the lenght and width of the stones.

--------------------------------------------------------------------------------------
Irregular Patterns
--------------------------------------------------------------------------------------

Irregular Pattern Random Seed: Randomizes the pattern.

X and Y amount: Controls the number of stones.

Offset: offsets the stones.

Random Slope Rotation: Rotates the sloping that's applied to the stone shapes.

Split Mode: Selects the mode that the Split control splits the stones.

Split: splits the stones in the pattern to make different patterns.

Size Random X and Y: Randomizes the stone sizes.

Color Variation Random Seed: Randomizes the color variation on the pattern.

Irregular Stone Scale: Controls the overall size of the stones.

Edge Roundness: Controls how round the edges of the stones are.

---------------------------------------------------------------------------------------
Irregular Pattern1
---------------------------------------------------------------------------------------

Rough or Smooth Stones: Switches between rough and smooth stones.

Split2: Secondary slpit control.

---------------------------------------------------------------------------------------
Irregular Pattern2
---------------------------------------------------------------------------------------

Sloped or Flat: Switches between stones that have a sloped surface or flat surface.

Irreg Pattern 2 Switch: Switches between two pattern presets one being more random than the other.

Mask Random Seed: Randomizes the mask used in randomizing the stone pattern.

Secondary Split mode: selects the way the stones are split.

Secondary Split: Splits the stones in the pattern to make different patterns.

Secondary Size Random X: Randomizes the size of stones on the x axis.

-----------------------------------------------------------------------------------------
Plaster
-----------------------------------------------------------------------------------------

Rough or flat: Rough textured plaster or tampered flat.

Plaster Thickness: Controls the thickness of the plaster between the stones.

Plaster Thickness Contrast: Secondary control for Plaster Thickness.

Plaster Blur: Blurs the mask that for where the plaster shows up.

Plaster Height: Controls the height of the plaster.

Stone Height: Controls the height of the stones.

Plaster Med Detail Scale: Controls the scale of a pattern used for roughing up the texture of the plaster.

Plaster Med Detail Blur: Blurs the pattern used in Plaster Med Detail Scale.

Plaster Micro Detail Strength: Controls the strength of a micro detail pattern that further roughs up the plaster.

-----------------------------------------------------------------------------------------------
Dirt
-----------------------------------------------------------------------------------------------

Dirt Level: Controls the spread of dirt on the material.

Dirt Contrast: Secondary control for Dirt Level.

Grunge Amount: Controls the amount of dirt that shows up on the material.

Edges Masking: Controls the spread on dirt on the edges.